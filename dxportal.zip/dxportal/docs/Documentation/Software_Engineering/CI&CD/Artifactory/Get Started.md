---
id: Get Started
title: Get Started
sidebar_label: Get Started
---
It's time to start your DevOps journey in the JFrog Platform. The Getting Started will help you get up and running with your selected JFrog environment - whether you are a Cloud or Self-Hosted user.

Start with the onboarding tools such as the quickstart guides and onboarding videos, and learn more about the JFrog Platform and all the products that make up the DevOps experience.

After you are oriented, you can continue to dive deeper into the JFrog Platform depending on your selected solution - JFrog Cloud or JFrog Self-Hosted.

## Onboarding the JFrog Platform

|JFrog Platform Overview|Onboarding Videos|QuickStarts|
|-------|--------|---------|
|Learn about the JFrog Platform and how it gives you an end-to-end  seamless experience from build to production using the different JFrog products.|Watch onboarding best practices videos that will help you get started with Artifactory, Xray, and Pipelines.|Quickstart guides designed to help you get started quickly and easily with setting up your JFrog Platform.|
|[Jrog Platform overview](https://www.jfrog.com/confluence/display/JFROG/JFrog+Platform+Overview)|[Onborading best practices](https://www.jfrog.com/confluence/display/JFROG/Onboarding+Best+Practices%3A+JFrog+Artifactory)|[QuickStart Guide](https://www.jfrog.com/confluence/display/JFROG/QuickStart+Guide%3A+JFrog+Self-Hosted)|

> This page is currently just a placeholder.
> It is a jumping point for guides and ideas for doing more with Build Tracker. If you have ideas for more, please help by [contributing](#contributing)!
