---
id: devsecops tools
title: DevSecOps Tools
sidebar_label: DevSecOps Tools      
---
Despite the best efforts by software companies, security breaches still occur. Since 2000, an estimated 3.5 billion people saw their personal data stolen. Part of the problem is that as software applications grow in codebase scale and complexity, so do the surface areas for security vulnerabilities and exploits.

Plus, as more organizations adopt a DevOps approach, which automates and integrates the processes between software development and IT teams, traditional security tools are often no longer adequate. Developers today need to embed security measures into every stage of the development workflow. When it comes to security for DevOps workflows, this practice is referred to as DevSecOps.

## What is DevSecOps?

DevSecOps is the practice of integrating security into a continuous integration, continuous delivery, and continuous deployment pipeline. By incorporating DevOps values into software security, security verification becomes an active, integrated part of the development process.

Much like DevOps, DevSecOps is an organizational and technical methodology that combines project management workflows with automated IT tools. DevSecOps integrates active security audits and security testing into agile development and DevOps workflows so that security is built into the product, rather than applied to a finished product.

### To implement DevSecOps, teams should

1. Introduce security throughout the software development lifecycle in order to minimize vulnerabilities in software code.
2. Ensure the entire DevOps team, including developers and operations teams, share responsibility for following security best practices.
3. Enable automated security checks at each stage of software delivery by integrating security controls, tools, and processes into the DevOps workflow.

With DevSecOps, security should be applied to each phase of the typical DevOps pipeline: plan, code, build, test, release, and deploy.

Continuous is a differentiated characteristic of a DevOps pipeline. This includes continuous integration, continuous delivery/deployment (CI/CD), continuous feedback, and continuous operations. Instead of one-off tests or scheduled deployments, each function occurs on an ongoing basis.

### In conclusion

As more development teams evolve their processes and embrace new tools, they need to be diligent with security. DevSecOps is a cyclical process, and should be continuously iterated and applied to every new code deployment. Exploits and attackers are constantly evolving and it is important that modern software teams evolve as well.
