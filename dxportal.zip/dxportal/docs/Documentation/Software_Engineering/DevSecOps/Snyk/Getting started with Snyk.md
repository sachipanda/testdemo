---
id: Getting started with Snyk
title: Getting Started With Snyk
sidebar_label: Getting started with Snyk
---

<p align="center">
  <img src="https://snyk.io/style/asset/logo/snyk-print.svg" />
</p>

<p align="center">
  <a href="https://snyk.io/docs/?utm_campaign=docs&utm_medium=github&utm_source=full_docs">Documentation</a> |
  <a href="https://snyk.io/test/">Test your project</a>
</p>

<p align="center">
  Snyk helps you find, fix and monitor known vulnerabilities in open source
</p>

> This page is currently just a placeholder.
> It is a jumping point for guides and ideas for doing more with Build Tracker. If you have ideas for more, please help by [contributing](#contributing)!
