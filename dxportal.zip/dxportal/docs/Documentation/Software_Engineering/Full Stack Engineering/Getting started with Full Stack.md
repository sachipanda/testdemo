---
id: Getting started with source clear
title: Getting Started With Source Clear
sidebar_label: Getting started with source clear
---

## A full stack developer is a web developer or engineer who works with both the front and back ends of a website or application—meaning they can tackle projects that involve databases, building user-facing websites, or even work with clients during the planning phase of projects

> This page is currently just a placeholder.
> It is a jumping point for guides and ideas for doing more with Build Tracker. If you have ideas for more, please help by [contributing](#contributing)
