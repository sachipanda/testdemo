---
id: Getting started with SRE
title: Getting Started With SRE
sidebar_label: Getting started with SRE
---
## What is Site Reliability Engineering (SRE)?

SRE is what you get when you treat operations as if it’s a software problem. Our mission is to protect, provide for, and progress the software and systems behind all of Google’s public services — Google Search, Ads, Gmail, Android, YouTube, and App Engine, to name just a few — with an ever-watchful eye on their availability, latency, performance, and capacity.

## What we do as SRE ?

Our job is a combination not found elsewhere in the industry. Like traditional operations groups, we keep important, revenue-critical systems up and running despite hurricanes, bandwidth outages, and configuration errors.

- [SRE VS DEVOPS](https://www.youtube.com/playlist?list=PLIivdWyY5sqJrKl7D2u-gmis8h9K66qoj)

- [SRE and DevOps Engineer with Google Cloud](https://www.pluralsight.com/paths/sre-and-devops-engineer-with-google-cloud?aid=7010a000002BWq6AAG&promo=&utm_source=non_branded&utm_medium=digital_paid_search_google&utm_campaign=IN_Dynamic&utm_content=&cq_cmp=846648680&gclid=Cj0KCQjwktKFBhCkARIsAJeDT0gne0bskh7HdH2wswPr4RlMYJdz1Co5L1hFo6T1p6ZY7QHp4CrzSJEaAg7-EALw_wcB)

- [SRE Certification](SRECertification.md)
