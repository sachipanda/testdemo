---
id: SRECertification
title: SRE Certification
sidebar_label: SRE Certification
---
## ABOUT SRE CERTIFICATION

 SRE (Site Reliability Engineer) Foundation Certification is a roadmap to the principles & practices that allows an organization to reliably and economically scale critical services. The course content of this Site Reliability Engineering certification revolves around the evolution of SRE and its future direction and empowers the participants with the practices, methods, and tools to engage people across the organization involved in reliability and stability evidenced through the use of real-life scenarios and case stories. After the completion of this SRE certification, participants will have tangible takeaways to leverage when back in the office such as understanding, setting, and tracking Service Level Objectives (SLO's).

* The SRE certification is curated with the fundamentals of key SRE sources, engaging with thought-leaders in the SRE space, and working with organizations embracing SRE to extract real-life best practices and aims towards spreading knowledge about the key principles & practices necessary for starting SRE adoption

## SRE CERTIFICATION OBJECTIVES

*The objective of Site Reliability Engineering certification includes a deep understanding of:*

1. The history of SRE and its emergence at Google
2. The inter-relationship of SRE with DevOps and other popular frameworks
3. The underlying principles behind SRE
4. Service Level Objectives (SLO's) and their user focus
5. Service Level Indicators (SLI's) and the modern monitoring landscape
6. Error budgets and the associated error budget policies
7. Toil and its effect on an organization's productivity
8. Some practical steps that can help to eliminate toil
9. Observability as something to indicate the health of a service
10. SRE tools, automation techniques, and the importance of security
11. Anti-fragility, our approach to failure and failure testing
12. The organizational impact that introducing SRE brings

## SRE CERTIFICATION BENEFITS

 1. Communicate with other engineers, product owners, and customers and come up with targets and measures.
 2. Introduce error budgets in order to measure risk, balance availability, and feature development.
 3. Automate tasks that require a human operator to work manually.
 4. Understand the systems and their connectivity.
 5. Discover the problems early to reduce the cost of failure.

## SRE CERTIFICATION EXAMINATION

1. Ensure that you have filled up the basic details.
2. This exam consists of 40 multiple-choice questions.
3. Candidates need to score a minimum of 65% of the total marks (i.e. 26 out of 40) to pass this examination.
4. The total duration of this examination is 90 minutes.
5. Candidates should Tick against only one correct answer in Multiple Choice Questions.
6. In case the participant does not score passing % then they will be granted a 2nd attempt at no additional cost. Re-examination can be taken up to 30 days from the date of the 1st exam attempt.
