import classnames from 'classnames';
import Layout from '@theme/Layout';
import Link from '@docusaurus/Link';
import React from 'react';
import styles from './styles.module.css';
import useBaseUrl from '@docusaurus/useBaseUrl';
import useDocusaurusContext from '@docusaurus/useDocusaurusContext';
import Footer from '../theme/sections/footer/footer';

const features = [
  {
    title: <React.Fragment>Documentation</React.Fragment>,
    imageUrl: 'img/DX-icon-document-color.svg',
    description: (
      <>
        <p>
          Browse through the library of documents, guides and examples to help you with your various developer needs.
        </p>
        <h5>Popular documents</h5>
        <ul>
          <li>Lorem ipsum dolor sit amet REFERENCE GUIDE <br /> <code>Software Engineering</code>  <code>Security</code></li>
          <li>Donec efficitur HOW-TO-GUIDE <br /> <code>Software Engineering</code></li>
          <li>Interdum et malesuada fames ac ante ipsum primis in faucibus REFERENCE GUIDE <code>Software Engineering</code></li>
          <li>Donec sollicitudin venenatis justo TUTORIAL <br /><code>Software Engineering</code>   <code>Platforms</code><br /><code>Test Automation & Quality Assurance</code></li>
          <li>Pellentesque eu rhoncus LEARNING MATERIAL <br /><code>Software Engineering</code></li>
        </ul>        
        <button type="button" onClick={() => alert('hey')}>
          Click me!
        </button>        
      </>
    ),
  },
  {
    title: <React.Fragment>Tools</React.Fragment>,
    imageUrl: 'img/DX-icon-toolbox-color2.svg',
    description: (
      <React.Fragment>
        Our teams work with industry standard tools and resources aimed at producing secure and innovative high-quality projects. Learn about the tools you have at your disposal in our technology catalog.
      </React.Fragment>
    ),
  },
  {
    title: <React.Fragment>Getting Started</React.Fragment>,
    imageUrl: 'img/DX-icon-newhire-color2.svg',
    description: (
      <React.Fragment>
        Onboard with your team using these helpful guides and task lists. Afterwards, get acquainted with our policies, workflows, capabilities and tools you will use on a regular basis.
      </React.Fragment>
    ),
  },
  {
    title: <React.Fragment>Communities</React.Fragment>,
    imageUrl: 'img/DX-icon-community-color2.svg',
    description: (
      <React.Fragment>
        Connect with a technology team today. Whether you are looking for assistance with a specific task or just seeking general guidance, you can find the appropriate community portal or links to group here.
      </React.Fragment>
    ),
  },  
];

function Feature({ key, imageUrl, title, description }) {
  const imgUrl = useBaseUrl(imageUrl);
  return (
    <div className={classnames('col col--6', styles.feature)}>
        {imageUrl ? (
          <div className="text--center">
            <img className={styles.featureImage} src={imgUrl} alt={title} />
          </div>
        ) : null}
      <div className="featureText">
        <h3>{title}</h3>
        <p>{description}</p>
      </div>
    </div>
  );
}

function Home() {
  const context = useDocusaurusContext();
  const { siteConfig = {} } = context;
  return (
    <Layout title={siteConfig.title} description={siteConfig.tagline}>
      <div>
        <div className={styles.heroContent}>
          <div className={styles.heroLeft}>
            <h1 className={styles.heroHeading}>Prepare for lift off</h1>
            <p className={styles.heroPara}>Fuel your knowledge, by tapping into the community's collection of documents and information. Then prepare to rocket your productivity as you connect with experts in the areas you want to learn more about.</p>
          </div>
          <div className={styles.heroRight}>
            <img src={useBaseUrl('img/DX-home-image-rocket.svg')} className={styles.heroBox} />
          </div>
        </div>        
      </div>

      <main>
        <div className="container1">
          <div className="leftSide">
            <div className={classnames('col col--6', styles.feature)}>
              <div className="text--center">
                <img className={styles.featureImage} src='img/DX-icon-document-color.svg' alt="Documentation" />
              </div>
              <h3 className="docTitle">Documentation</h3>
              <p>
                <p className="docPara">
                  Browse through the library of documents, guides and examples to help you with your various developer needs.
                </p>
                <h5 className="docHeader">Popular documents</h5>
                <ul className="doclist">
                  <li><span className="doclists">Welcome to DX Documentation</span><span className="docLink"> REFERENCE GUIDE</span><br /> <code className="docbutton">Software Engineering</code>  <code className="docbutton">Security</code></li>
                  <li><span className="doclists">Donec efficitur</span><span className="docLink"> HOW-TO-GUIDE</span> <br /> <code className="docbutton">Software Engineering</code></li>
                  <li><span className="doclists">Interdum et malesuada fames ac ante ipsum primis in faucibus</span><span className="docLink"> REFERENCE GUIDE</span> <br /> <code className="docbutton">Software Engineering</code></li>
                  <li><span className="doclists">Donec sollicitudin venenatis justo</span><span className="docLink"> TUTORIAL</span> <br /><code className="docbutton">Software Engineering</code>   <code className="docbutton">Platforms</code><br /><code className="docbutton">Test Automation & Quality Assurance</code></li>
                  <li><span className="doclists">Software Engineering</span><span className="docLink"> LEARNING MATERIAL</span> <br /><code className="docbutton">Software Engineering</code></li>
                </ul>    
                <a href='docs/Documentation/Portal Contribution/documentation'>
                  <button className="buttonLeft" type="button">
                    Explore Documents
                  </button> 
                </a> 
              </p>              
            </div>    
          </div>

          <div className="rightSide1">
            <div className={classnames('col col--6', styles.feature)}>
              <div className="text--center">
                <img className={styles.featureImage} src='img/DX-icon-toolbox-color2.svg' alt="Tools" />
              </div>
              <h3 className="docTitle">Tools</h3>
              <div>
                <p className="docPara">
                  Our teams work with industry standard tools and resources aimed at producing secure and innovative high-quality projects. Learn about the tools you have at your disposal in our technology catalog.
                </p>

                <a href="http://www.google.com" target="_blank">
                  <button className="buttonRight" type="button" onclick={() => location.href="http://www.google.com"}>
                    Learn More  <img src="img/DX-external-white.svg" alt="" width="15px" height="15px"></img>
                  </button>  
                </a>
                <br />              
              </div>              
            </div>
          </div>

          <div className="rightSide2">
            <div className={classnames('col col--6', styles.feature)}>
              <div className="text--center">
                <img className={styles.featureImage} src='img/DX-icon-community-color2.svg' alt="Communities" />
              </div>
              <h3 className="docTitle">Communities</h3>
              <div>
                <p className="docPara">
                Connect with a technology team today. Whether you are looking for assistance with a specific task or just seeking general guidance, you can find the appropriate community portal or links to group here.
                </p>

                <a href="http://www.google.com" target="_blank">
                  <button className="buttonRight" type="button" onclick={() => location.href="http://www.google.com"}>
                    View Communities  <img src="img/DX-external-white.svg" alt="" width="15px" height="15px"></img>
                  </button>
                </a>
                <br />                
              </div>              
            </div>
          </div>

          <div className="rightSide3">
            <div className={classnames('col col--6', styles.feature)}>
              <div className="text--center">
                <img className={styles.featureImage} src='img/DX-icon-newhire-color2.svg' alt="Getting Started" />
              </div>
              <h3 className="docTitle">Getting Started</h3>
              <div>
                <p className="docPara">
                Onboard with your team using these helpful guides and task lists. Afterwards, get acquainted with our policies, workflows, capabilities and tools you will use on a regular basis.
                </p>
                <a href="http://www.google.com" target="_blank">
                <button className="buttonRight" type="button" onclick={() => location.href="http://www.google.com"}>
                  Get Started now  <img src="img/DX-external-white.svg" alt="" width="15px" height="15px"></img>
                </button> 
                </a>  
                <br />             
              </div>              
            </div>
          </div>
        </div>
      </main>
    </Layout>
  );
}

export default Home;
